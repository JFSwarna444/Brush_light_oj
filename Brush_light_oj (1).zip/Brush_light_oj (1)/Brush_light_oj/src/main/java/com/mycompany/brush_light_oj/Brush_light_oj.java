package com.mycompany.brush_light_oj;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class Brush_light_oj extends Application {

    public static void main(String[] args) {

        launch(args);

    }

    @Override
    public void start(Stage stage) throws Exception {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody

        stage.setTitle("Brush 1 to 3 in light oj");

        Button bush_1 = new Button("Brush(i)");
        Button bush_2 = new Button("Brush(ii)");
        Button bush_3 = new Button("Brush(iii)");
        Button bush_4 = new Button("Brush(iv)");

        TilePane r = new TilePane();

        Label l = new Label("No result is still found");

        EventHandler<ActionEvent> event = (ActionEvent e) -> {

            File file = new File("Brush_1.txt");

            try {

                Scanner scanner = new Scanner(file);

                int i = 0, testCases, n;

                int a[];

                StringBuilder sb = new StringBuilder();

                while (scanner.hasNextLine()) {

                    if (i == 0) {

                        testCases = Integer.parseInt(scanner.nextLine().trim());

                    } else {

                        n = Integer.parseInt(scanner.nextLine().trim());

                        a = new int[n];

                        String s[] = scanner.nextLine().split(" ");

                        int index = 0;

                        for (String j : s) {

                            a[index++] = Integer.parseInt(j);

                        }

                        sb.append("Case ").append(i).append(": ").append(totalDustUnits(n, a)).append("\n");

                    }

                    ++i;

                }

                l.setText("");

                l.setText(sb.toString());

            } catch (FileNotFoundException ex) {
                Logger.getLogger(Brush_light_oj.class.getName()).log(Level.SEVERE, null, ex);
            }

        };

        EventHandler<ActionEvent> event1 = (ActionEvent e) -> {

            StringBuilder sb = new StringBuilder();

            File file = new File("Brush_2.txt");

            try {

                Scanner scanner = new Scanner(file);

                int testCases, n = 0, k, w = 0;
                long x[] = null, y[] = null;

                int i = 0;

                while (scanner.hasNextLine()) {

                    if (i == 0) {

                        testCases = Integer.parseInt(scanner.nextLine().trim());

                    } else {

                        String st[] = scanner.nextLine().split(" ");

                        n = Integer.parseInt(st[0]);
                        w = Integer.parseInt(st[1]);

                        x = new long[n];
                        y = new long[n];

                        for (int j = 0; j < n; ++j) {

                            String s[] = scanner.nextLine().split(" ");

                            x[j] = Long.parseLong(s[0]);
                            y[j] = Long.parseLong(s[1]);

                        }

                    }

                    ++i;

                }

                sb.append("Case ").append(i).append(": ").append(brush_2(n, w, x, y)).append("\n");

            } catch (FileNotFoundException ex) {
                Logger.getLogger(Brush_light_oj.class.getName()).log(Level.SEVERE, null, ex);
            }

            l.setText("");

            l.setText(sb.toString());

        };

        EventHandler<ActionEvent> event3 = (ActionEvent e) -> {

            Scanner scanner = new Scanner("Brush_3.txt");

            StringBuilder sb = new StringBuilder();

            int testCases, n, k;

            long w;

            long x[], y[];

            int i = 0;

            while (scanner.hasNextLine()) {

                try {

                    if (i == 0) {

                        testCases = Integer.parseInt(scanner.nextLine().trim());

                    } else {

                        String s[] = scanner.nextLine().split(" ");

                        n = Integer.parseInt(s[0]);
                        w = Long.parseLong(s[1]);
                        k = Integer.parseInt(s[2]);

                        x = new long[n];

                        y = new long[n];

                        for (int j = 0; j < n; ++j) {

                            String st[] = scanner.nextLine().split(" ");

                            x[j] = Long.parseLong(st[0]);
                            y[j] = Long.parseLong(st[1]);

                        }

                        long dp[][] = new long[n][n];

                        for (int j = 0; j < n; ++j) {

                            for (int m = 0; m < n; ++m) {

                                dp[j][m] = -1;

                            }

                        }

                        sb.append("Case ").append(i).append(": ").append(solve(dp, 0, 0, y, k, n, w)).append("\n");

                    }

                    ++i;

                    l.setText("");

                    l.setText(sb.toString());

                } catch (Exception e1) {

                }

            }

        };

        bush_1.setOnAction(event);
        bush_2.setOnAction(event1);
        bush_3.setOnAction(event3);

        r.getChildren().add(bush_1);
        r.getChildren().add(bush_2);
        r.getChildren().add(bush_3);
        r.getChildren().add(l);

        // create a scene
        Scene sc = new Scene(r, 200, 200);

        // set the scene
        stage.setScene(sc);

        stage.show();

    }

    static int totalDustUnits(int n, int[] a) {

        int sum = 0;

        for (int i : a) {

            if (i >= 0) {
                sum += i;
            }

        }

        return sum;

    }

    static long brush_2(int n, int w, long x[], long y[]) {

        long ans = 0L;

        //int n = x.length;
        sort(y, 0, n - 1);

        long dust = y[0];

        for (int i = 0, index = 0; i < n; ++i) {

            if (dust + w < y[i]) {

                dust = y[i];
                ++index;

                ++ans;

            }

        }

        return ans;

    }

    static void merge(long a[], int left, int right, int mid) {

        int n1 = mid - left + 1, n2 = right - mid;

        long L[] = new long[n1];

        long R[] = new long[n2];

        for (int i = 0; i < n1; i++) {

            L[i] = a[left + i];

        }

        for (int i = 0; i < n2; i++) {

            R[i] = a[mid + 1 + i];

        }

        int i = 0, j = 0, k1 = left;

        while (i < n1 && j < n2) {

            if (L[i] <= R[j]) {

                a[k1] = L[i];

                i++;

            } else {

                a[k1] = R[j];

                j++;

            }

            k1++;

        }

        while (i < n1) {

            a[k1] = L[i];

            i++;

            k1++;

        }

        while (j < n2) {

            a[k1] = R[j];

            j++;
            k1++;

        }

    }

    static void sort(long a[], int left, int right) {

        if (left >= right) {

            return;

        }

        int mid = (left + right) / 2;

        sort(a, left, mid);

        sort(a, mid + 1, right);

        merge(a, left, right, mid);

    }

    static long solve(long dp[][], int position, int moves, long y[], int k, int n, long w) {

        if (position >= n || moves >= k) {
            return 0L;
        }
        if (dp[position][moves] != -1) {
            return dp[position][moves];
        }

        int i, count = 0;

        for (i = 0; i < n - position; ++i) {

            if (y[position] + w < y[position + i]) {

                break;

            }

            ++count;

        }

        long ans = Math.max(count + solve(dp, position + i, moves + 1, y, k, n, w), solve(dp, position + 1, moves, y, k, n, w));
        dp[position][moves] = ans;

        return dp[position][moves];

    }

}
