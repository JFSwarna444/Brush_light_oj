
import java.util.Scanner;

public class C_George_and_Job {

    static Scanner in = new Scanner(System.in);

    static int testCases, n;

    static long a[];

    static int m, k;

    static void solve() {

        long prefix[] = new long[n + 1];

        for (int i = 1; i <= n; ++i) {

            prefix[i] = prefix[i - 1] + a[i];

        }

        long dp[][] = new long[n + 1][k + 1];

        dp[1][1] = prefix[1];

        for (int i = m; i <= n; ++i) {

            for (int bag = 1; bag <= k; ++bag) {

                dp[i][bag] = Math.max(dp[i - 1][bag], dp[i - m][bag - 1] + (prefix[i] - prefix[i - m]));

            }

        }

        System.out.print(dp[n][k]);

    }

    public static void main(String[] args) {

        testCases = 1;

        for (int t = 0; t < testCases; ++t) {

            input();
            solve();

        }

    }

    private static void input() {

        n = in.nextInt();
        m = in.nextInt();
        k = in.nextInt();

        a = new long[n + 1];

        for (int i = 1; i <= n; ++i) {

            a[i] = in.nextLong();

        }

    }

}
/*

7 1 3
2 10 7 18 5 33 0

 */

 /*

5 2 1
1 2 3 4 5

 */

 /*

5 2 2
1 2 3 4 5

 */
