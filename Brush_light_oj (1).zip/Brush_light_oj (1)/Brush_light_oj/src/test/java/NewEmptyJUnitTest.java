
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NewEmptyJUnitTest {

    public NewEmptyJUnitTest() {

    }

    @org.junit.jupiter.api.BeforeAll
    public static void setUpClass() throws Exception {
    }

    @org.junit.jupiter.api.AfterAll
    public static void tearDownClass() throws Exception {
    }

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

    @org.junit.jupiter.api.AfterEach
    public void tearDown() throws Exception {
    }

    @Test
    public void testAssert() {

        Account account = new Account("Amit", 3370L, 521);

        assertEquals(true, account.deposit((float) 5.6));
        assertEquals(false, account.deposit((float) 5.6 * -1));
        assertEquals(false, account.deposit((float) 5.6 * -1));

        assertEquals(false, account.withdraw((float) -4.5, (float) 4.9));
        assertEquals(false, account.withdraw((float) 4.5, (float) -4.9));
        assertEquals(true, account.withdraw((float) 4.5, (float) 2.9));
        assertEquals(true, account.withdraw((float) 2.5, (float) 4.9));
        assertEquals(false, account.withdraw((float) 650, (float) 4.9));
        assertEquals(false, account.withdraw((float) 517, (float) 4.9));

    }

}
